import './App.css';
import { TreeDataView } from './components/TreeView';

function App() {
  return (
    <div className="App" >
          <TreeDataView/>
    </div>
  );
}

export default App;
